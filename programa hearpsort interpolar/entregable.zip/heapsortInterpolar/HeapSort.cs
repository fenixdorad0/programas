﻿namespace Ping_LoL
{
    internal class HeapSort
    {
        private int heapSize;

        private void BuildHeap(int[] arr)
        {
            heapSize = arr.Length - 1;
            int i = heapSize / 2;
            while (i >= 0)
            {
                Heapify(arr, i);
                i--;
            }
        }

        private void Swap(int[] arr, int x, int y)//function to swap elements
        {
            int temp = arr[x];
            arr[x] = arr[y];
            arr[y] = temp;
        }
        private void Heapify(int[] arr, int index)
        {
            int left = 2 * index;
            int right = 2 * index + 1;
            int largest = index;

            if (left <= heapSize && arr[left] > arr[index])
            {
                largest = left;
            }

            if (right <= heapSize && arr[right] > arr[largest])
            {
                largest = right;
            }

            if (largest != index)
            {
                Swap(arr, index, largest);
                Heapify(arr, largest);
            }
        }
        public void PerformHeapSort(int[] arr)
        {
            BuildHeap(arr);
            int i = arr.Length - 1;
            
            while ( i >= 0)
            {
                Swap(arr, 0, i);
                heapSize--;
                Heapify(arr, 0);
                i=i-1;
            }
            
        }
       
    }
}