﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Topo
{
    public partial class Form1 : Form
    {
        public string[,] jugadas = new string[3, 4];
        public Button[,] botones = new Button[3, 4];
        public Random r = new Random();
        public int nx, ny,xn,yn;
        byte puntos = 0;       

        public Form1()
        {
            InitializeComponent();            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Button btn in this.panel1.Controls)
            {
                Button b = (Button)btn;
                string[] x = b.Tag.ToString().Split(',');
                int z = Convert.ToInt16(x[0]);
                int w = Convert.ToInt16(x[1]);
                botones[z, w] = b;
            }
            Icon a;
            a = Properties.Resources.hammer1;
            panel1.Cursor = new Cursor(a.Handle);
        }
        private void button13_Click(object sender, EventArgs e) // BOTON JUGAR
        {
            automatico();
        }

        private void automatico()
        {
            timer1.Start();
            nx = r.Next(3);
            ny = r.Next(4);
            xn = r.Next(3);
            yn = r.Next(4);
            if (jugadas[nx, ny] == null)
            {
                botones[nx, ny].BackColor = Color.Orange;
                botones[xn, yn].BackColor = Color.Red;

            }
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string[] pos = btn.Tag.ToString().Split(',');   // separa una matriz en subcadenas
            byte x = Convert.ToByte(pos[0]);    //x se comvierte en las filas de la matriz=pos[0]        
            byte y = Convert.ToByte(pos[1]);    //y se comvierte en las columnas de la matriz=pos[1]     
            if (botones[x, y].BackColor == Color.Red)
            {
                if (puntos == 0)
                {
                    timer1.Stop();
                    MessageBox.Show("paila");
                    MessageBox.Show("perdio");
                    Application.Restart();
                }
                if(puntos>0)
                {
                    puntos--;
                    label_puntos.Text = puntos.ToString();
                }
            }
            if(botones[x, y].BackColor == Color.Orange)
            {
                puntos++;
                label_puntos.Text = puntos.ToString();                
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            botones[nx,ny].BackColor = Color.White;
            botones[xn, yn].BackColor = Color.White;
            timer1.Stop();
            automatico();
        }
    }
}
