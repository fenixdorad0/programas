package fenixa;

import javax.swing.JOptionPane;

public class matrizes {
	

	public static void main(String[] args) {
	int a[][];int f,c;
	a=new int [3][3];
	for(f=0;f<3;f++){
		for(c=0;c<3;c++){
			a[f][c]=Integer.parseInt(JOptionPane.showInputDialog("el dato de la matriz a en posicion fila  "+ (f+1) + "  columna  "+ (c+1) ));
		}
	}
	for(f=0;f<3;f++){
		for(c=0;c<3;c++){
			System.out.println(a[f][c]);
			}
		}	
		
		
	}
}
