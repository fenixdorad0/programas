﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triqui
{
    public partial class Form1 : Form
    {
        //private Button pic1, pic2;//
        private bool valida = true;
        //private string simbolo_X = "X";
        //private string simbolo_O = "O";
        //private byte y = 0; //para comparar columnas        
        public byte count = 0; //contador
        public string[,] jugadas = new string[3, 3];

        public Form1()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }



        private void button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string[] pos = btn.Tag.ToString().Split(',');   // separa una matriz en subcadenas
            byte x = Convert.ToByte(pos[0]);    //x se comvierte en las filas de la matriz=pos[0]        
            byte y = Convert.ToByte(pos[1]);    //y se comvierte en las columnas de la matriz=pos[1]
            string figura;
            if (valida)
            {
                figura = "X";
            }
            else
            {
                figura = "O";
            }
            jugadas[x, y] = figura;
            btn.Text = figura;
            filaSuperiorLlena(figura, x, y);
            filaCentralLlena(figura, x, y);
            filaInferiorLlena(figura, x, y);
            columnaSuperiorLlena(figura, x, y);
            columnaCentralLlena(figura, x, y);
            columnaInferiorLlena(figura, x, y);
            //diagonalPrincipalLlena(figura, x, y);
            validaciones();
            valida = !valida;
        }

        private void validaciones()
        {
            if (count == 3)
            {
                MessageBox.Show("buena");
                count = 0;
                Application.Restart();
            }
        }
        //-------------------------------------------------------------------------------------------------------------------------------//
        //-----------------------------------------------------Simbolo_X_O----------------------------------------------------------------//
        //-----FILAS-------------------------------------------------------------------------------------------------------------------//
        private bool filaSuperiorLlena(string figura, byte x, byte y)
        {
            if (x == 0)
            {
                count = 0;
                for (byte c = 0; c < 3; c++)
                {
                    if (jugadas[x, c] == figura)
                    {
                        count++;
                    }
                }
            }
            return true;
        }
        private bool filaCentralLlena(string figura, byte x, byte y)
        {
            if (x == 1)
            {
                count = 0;
                for (byte c = 0; c < 3; c++)
                {
                    if (jugadas[x, c] == figura)
                    {
                        count++;
                    }
                }
            }
            return true;
        }
        private bool filaInferiorLlena(string figura, byte x, byte y)
        {
            if (x == 2)
            {
                count = 0;
                for (byte c = 0; c < 3; c++)
                {
                    if (jugadas[x, c] == figura)
                    {
                        count++;
                    }
                }
            }
            return true;
        }
        //-----COLUMNAS-------------------------------------------------------------------------------------------------------------------//
        private bool columnaSuperiorLlena(string figura, byte x, byte y)
        {
            if (y == 0)
            {
                count = 0;
                for (byte c = 0; c < 3; c++)
                {
                    if (jugadas[c, y] == figura)
                    {
                        count++;
                    }
                }
            }
            return true;
        }
        private bool columnaCentralLlena(string figura, byte x, byte y)
        {
            if (y == 1)
            {
                count = 0;
                for (byte c = 0; c < 3; c++)
                {
                    if (jugadas[c, y] == figura)
                    {
                        count++;
                    }
                }
            }
            return true;
        }
        private bool columnaInferiorLlena(string figura, byte x, byte y)
        {
            if (y == 2)
            {
                count = 0;
                for (byte c = 0; c < 3; c++)
                {
                    if (jugadas[c, y] == figura)
                    {
                        count++;
                    }
                }
            }
            return true;
        }
        //-----DIAGONALES-------------------------------------------------------------------------------------------------------------------//
        private bool diagonalPrincipalLlena(string figura, byte x, byte y)
        {
            
            for (x = 0; x < 3; x++)
            {
                if (jugadas[x,x] == figura)
                {
                    count++;
                }
            }
            if (count !=3)
            {
                count = 0;
            }
            return true;
        }
    }
}
